import 'dart:async';
import '../models/student_model.dart';
import '../models/attendance_model.dart';
import '../models/visit_model.dart';
import 'local_db_service.dart';
import 'firestore_service.dart';
import 'connectivity_service.dart';

/// خدمة المزامنة الكاملة (Hive ↔ Firestore)
///
/// المبدأ في كل فتحة للتطبيق:
///   1. اسحب كل البيانات من Firestore وادمجها محليًا (remote wins if newer)
///   2. ارفع أي تغييرات محلية معلقة (needsSync = true)
///   3. استمع للتغييرات اللحظية (real-time listeners)
///
/// ده بيضمن إن أي خادم (جديد أو قديم، مهما حصل) يلاقي البيانات كلها.
class SyncService {
  final LocalDbService _local;
  final FirestoreService _remote;
  final ConnectivityService _connectivity;

  StreamSubscription? _studentsSub;
  StreamSubscription? _attendanceSub;
  StreamSubscription? _visitsSub;
  StreamSubscription<bool>? _connectivitySub;
  bool _isSyncing = false;

  final StreamController<void> _onDataChanged =
      StreamController<void>.broadcast();
  Stream<void> get onDataChanged => _onDataChanged.stream;

  SyncService(this._local, this._remote, this._connectivity);

  // ─── بداية الخدمة ─────────────────────────────────────────────────────────

  Future<void> start() async {
    if (!await _connectivity.isOnline()) {
      // أوفلاين: انتظر عودة الاتصال
      _connectivitySub =
          _connectivity.onStatusChange.listen((online) async {
        if (online) {
          await _fullSync();
          _listenToRemoteChanges();
        } else {
          _cancelListeners();
        }
      });
      return;
    }

    // أونلاين: مزامنة كاملة ثم استماع لحظي
    await _fullSync();
    _listenToRemoteChanges();

    _connectivitySub =
        _connectivity.onStatusChange.listen((online) async {
      if (online) {
        await _fullSync();
        _listenToRemoteChanges();
      } else {
        _cancelListeners();
      }
    });
  }

  // ─── المزامنة الكاملة ──────────────────────────────────────────────────────

  /// يُنفَّذ في كل فتحة للتطبيق أونلاين
  /// الترتيب مهم: اسحب أولاً ثم ارفع
  Future<void> _fullSync() async {
    if (_isSyncing) return;
    _isSyncing = true;
    try {
      await _pullFromFirestore();   // 1. اسحب من السحابة
      await _pushPendingStudents(); // 2. ارفع المحلي المعلق
      await _pushPendingAttendance();
      await _pushPendingVisits();
    } finally {
      _isSyncing = false;
    }
  }

  /// سحب كل البيانات من Firestore ودمجها مع المحلية
  /// يُستخدم دائمًا (سواء الداتا فاضية أو لأ)
  Future<void> _pullFromFirestore() async {
    try {
      bool changed = false;

      // ── الشباب ──
      final remoteStudents = await _remote.fetchAllStudents();
      for (final r in remoteStudents) {
        final local = _local.getStudent(r.id);
        if (local == null) {
          await _local.saveStudent(r.copyWith(needsSync: false));
          changed = true;
        } else if (!local.needsSync &&
            r.updatedAt.isAfter(local.updatedAt)) {
          await _local.saveStudent(r.copyWith(needsSync: false));
          changed = true;
        }
        // لو local.needsSync = true → الأحدث محليًا → لا تكتب فوقه
      }

      // ── الحضور ──
      final remoteAtt = await _remote.fetchAllAttendance();
      for (final r in remoteAtt) {
        final localList =
            _local.getAttendanceForStudent(r.studentId);
        final local = localList.where((l) => l.id == r.id).firstOrNull;
        if (local == null) {
          await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
          changed = true;
        } else if (!local.needsSync &&
            r.updatedAt.isAfter(local.updatedAt)) {
          await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
          changed = true;
        }
      }

      // ── الافتقاد ──
      final remoteVisits = await _remote.fetchAllVisits();
      for (final r in remoteVisits) {
        final local = _local.getVisit(r.id);
        if (local == null) {
          await _local.saveVisit(r.copyWith(needsSync: false));
          changed = true;
        } else if (!local.needsSync &&
            r.updatedAt.isAfter(local.updatedAt)) {
          await _local.saveVisit(r.copyWith(needsSync: false));
          changed = true;
        }
      }

      if (changed) _onDataChanged.add(null);
    } catch (_) {
      // فشل السحب → كمّل بالداتا الموجودة محليًا
    }
  }

  // ─── رفع التغييرات المعلقة ─────────────────────────────────────────────────

  Future<void> syncNow() async {
    if (_isSyncing) return;
    _isSyncing = true;
    try {
      if (!await _connectivity.isOnline()) return;
      await _pushPendingStudents();
      await _pushPendingAttendance();
      await _pushPendingVisits();
    } finally {
      _isSyncing = false;
    }
  }

  Future<void> _pushPendingStudents() async {
    for (final s in _local.getStudentsNeedingSync()) {
      try {
        await _remote.pushStudent(s);
        await _local.saveStudent(s.copyWith(needsSync: false));
      } catch (_) {}
    }
  }

  Future<void> _pushPendingAttendance() async {
    final pending = _local.getAttendanceNeedingSync();
    if (pending.isEmpty) return;
    try {
      await _remote.pushAttendanceBatch(pending);
      await _local.saveAttendanceBatch(
          pending.map((r) => r.copyWith(needsSync: false)).toList());
    } catch (_) {}
  }

  Future<void> _pushPendingVisits() async {
    final pending = _local.getVisitsNeedingSync();
    if (pending.isEmpty) return;
    try {
      await _remote.pushVisitBatch(pending);
      for (final v in pending) {
        await _local.saveVisit(v.copyWith(needsSync: false));
      }
    } catch (_) {}
  }

  // ─── الاستماع اللحظي ──────────────────────────────────────────────────────

  void _listenToRemoteChanges() {
    _studentsSub?.cancel();
    _studentsSub =
        _remote.watchStudents().listen(_mergeRemoteStudents);

    _attendanceSub?.cancel();
    _attendanceSub =
        _remote.watchAttendance().listen(_mergeRemoteAttendance);

    _visitsSub?.cancel();
    _visitsSub =
        _remote.watchVisits().listen(_mergeRemoteVisits);
  }

  void _mergeRemoteStudents(List<StudentModel> remotes) async {
    bool changed = false;
    for (final r in remotes) {
      final local = _local.getStudent(r.id);
      if (local == null) {
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync &&
          r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveStudent(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void _mergeRemoteAttendance(List<AttendanceRecord> remotes) async {
    bool changed = false;
    for (final r in remotes) {
      final localList =
          _local.getAttendanceForStudent(r.studentId);
      final local =
          localList.where((l) => l.id == r.id).firstOrNull;
      if (local == null) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync &&
          r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveAttendanceRecord(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void _mergeRemoteVisits(List<VisitRecord> remotes) async {
    bool changed = false;
    for (final r in remotes) {
      final local = _local.getVisit(r.id);
      if (local == null) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      } else if (!local.needsSync &&
          r.updatedAt.isAfter(local.updatedAt)) {
        await _local.saveVisit(r.copyWith(needsSync: false));
        changed = true;
      }
    }
    if (changed) _onDataChanged.add(null);
  }

  void _cancelListeners() {
    _studentsSub?.cancel();
    _attendanceSub?.cancel();
    _visitsSub?.cancel();
  }

  void dispose() {
    _cancelListeners();
    _connectivitySub?.cancel();
    _onDataChanged.close();
  }
}
